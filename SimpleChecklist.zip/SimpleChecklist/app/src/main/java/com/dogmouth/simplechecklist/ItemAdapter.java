package com.dogmouth.simplechecklist;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.dogmouth.simplechecklist.data.ItemContract;
import com.dogmouth.simplechecklist.data.ItemContractHelper;

import org.w3c.dom.Text;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.dogmouth.simplechecklist.data.ItemContract.ItemEntry.COLUMN_ITEMS;
import static com.dogmouth.simplechecklist.data.ItemContract.ItemEntry.TABLE_NAME;

public class ItemAdapter extends ArrayAdapter<ItemList>  {


    public ItemAdapter(@NonNull Context context, ArrayList<ItemList> items) {
        super(context, 0, items);
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listitemview = convertView;
        if(listitemview == null){
            listitemview = LayoutInflater.from(getContext()).inflate(R.layout.listview_single_item_layout, parent,false);
        }

        ImageButton imageButton = (ImageButton) listitemview.findViewById(R.id.list_item_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

               // Toast.makeText(getContext(), "Item Deleted", Toast.LENGTH_SHORT).show();
                ItemList currentitem =getItem((position));
                remove(currentitem);
                notifyDataSetChanged();


            }
        });


        ItemList currentitem = getItem(position);
        TextView listtext = (TextView) listitemview.findViewById(R.id.listview_text);
        listtext.setText(currentitem.getItemname());
        return listitemview;
    }

}
