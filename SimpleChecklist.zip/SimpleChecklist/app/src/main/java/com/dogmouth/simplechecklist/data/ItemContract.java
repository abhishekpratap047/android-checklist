package com.dogmouth.simplechecklist.data;

import android.provider.BaseColumns;

public final class ItemContract {

    public ItemContract(){}

    public static class ItemEntry implements BaseColumns {

        public static final String TABLE_NAME = "Items";
        public static final String COLUMN_ITEMS = "Data";

    }

}
