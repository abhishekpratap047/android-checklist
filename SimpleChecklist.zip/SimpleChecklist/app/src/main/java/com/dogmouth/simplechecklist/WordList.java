package com.dogmouth.simplechecklist;

public class WordList {

    private String item;
    public int key;

    public WordList(String string, int keyvalue){

        item = string;
        key = keyvalue;

    }

    public String getItem(){
        return item;
    }

}
