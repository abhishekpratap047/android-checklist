package com.dogmouth.simplechecklist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.dogmouth.simplechecklist.data.ItemContract;
import com.dogmouth.simplechecklist.data.ItemContractHelper;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import static com.dogmouth.simplechecklist.data.ItemContract.ItemEntry.COLUMN_ITEMS;
import static com.dogmouth.simplechecklist.data.ItemContract.ItemEntry.TABLE_NAME;
import static com.dogmouth.simplechecklist.data.ItemContractHelper.DELETE_ALL_ROWS;
import static com.dogmouth.simplechecklist.data.ItemContractHelper.DELETE_ENTRIES;

public class MainActivity extends AppCompatActivity {


    final ArrayList<ItemList> items = new ArrayList<ItemList>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            // Set the local night mode to some value
            getDelegate().setLocalNightMode(
                    AppCompatDelegate.MODE_NIGHT_YES);
            // Now recreate for it to take effect
            recreate();
        }
        setContentView(R.layout.activity_main);
        //Find Views
        final ImageButton imageButton = findViewById(R.id.addbutton);
        final EditText editText = findViewById(R.id.edittexttoolbar);
        //ArrayList

        final TextView txtnothing = findViewById(R.id.textViewnothing);

        final EditText edittext = (EditText) findViewById(R.id.edittexttoolbar);




        ///FROM ONRESUME

        ItemContractHelper helper = new ItemContractHelper(MainActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();
        final ItemAdapter itemAdapter = new ItemAdapter(MainActivity.this, items);
        final ListView list = (ListView) findViewById(R.id.list_item);

        String[] projection = {
                COLUMN_ITEMS
        };

        Cursor cursor = db.query(TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        while (cursor.moveToNext()){
            String str = cursor.getString(cursor.getColumnIndex(COLUMN_ITEMS));
            items.add(new ItemList(str));
        }
        cursor.close();
        list.setAdapter(itemAdapter);

        db.execSQL(DELETE_ALL_ROWS);

        ///


        if (items.isEmpty() == false) {
            txtnothing.setVisibility(View.INVISIBLE);
        } else {
            txtnothing.setVisibility(View.VISIBLE);
        }

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = editText.getText().toString();
                if (str == null || str.trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "Empty Item", Toast.LENGTH_SHORT).show();
                } else {

                    // add ADDITEM method here
                    items.add(new ItemList(str));
                    list.setAdapter(itemAdapter);
                    editText.setText("");
                    if (items.isEmpty() == false) {
                        txtnothing.setVisibility(View.INVISIBLE);
                    } else {
                        txtnothing.setVisibility(View.VISIBLE);
                    }

                }
            }
        });


    }

    @Override
    protected void onStop() {
        super.onStop();

        //DB ADD
          ItemContractHelper helper = new ItemContractHelper(MainActivity.this);
          SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();


       //   values.put(COLUMN_ITEMS, str);
       //   long newRowId = db.insert(TABLE_NAME, null, values);
        //DB ADD END

        int counter = 0;

        Log.v("ITEM SIZE", Integer.toString(items.size()));
        while (counter < items.size()){



            String str = items.get(counter).getItemname();

            values.put(COLUMN_ITEMS, str );

            long newRowId = db.insert(TABLE_NAME, null, values);

            Log.v("Counter : ", Integer.toString(counter));
            Log.v("Item : ", items.get(counter).getItemname());

            counter = counter + 1;

        }
        counter = 0;

    }

    @Override
    protected void onRestart() {
        super.onRestart();

        items.clear();

        ItemContractHelper helper = new ItemContractHelper(MainActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();

        String[] projection = {
                COLUMN_ITEMS
        };

        Cursor cursor = db.query(TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        while (cursor.moveToNext()){
            String str = cursor.getString(cursor.getColumnIndex(COLUMN_ITEMS));
            items.add(new ItemList(str));
        }
        cursor.close();

        db.execSQL(DELETE_ALL_ROWS);



    }
}