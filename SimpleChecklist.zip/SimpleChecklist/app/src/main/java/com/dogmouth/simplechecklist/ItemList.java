package com.dogmouth.simplechecklist;

public class ItemList {
    private String itemname;

    public ItemList(String item){
        itemname = item;
    }

    public String getItemname(){
        return itemname;
    }
}
